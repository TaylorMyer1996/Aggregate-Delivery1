import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, Truck, Calendar, DollarSign, UserPlus, List, FileText } from "lucide-react";
import dynamic from "next/dynamic";
import jsPDF from "jspdf";
import "jspdf-autotable";

const Map = dynamic(() => import("@/components/Map"), { ssr: false });

export default function HomePage() {
  const [showMap, setShowMap] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [weight, setWeight] = useState(0);
  const [distance, setDistance] = useState(0);
  const [quote, setQuote] = useState(null);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [bookings, setBookings] = useState([]);
  const [filterDate, setFilterDate] = useState("");

  const calculateQuote = () => {
    const cost = distance * 2 + weight * 0.05;
    setQuote(cost);
  };

  const handleBooking = () => {
    fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ distance, weight, quote }),
    })
      .then((res) => res.json())
      .then((data) => {
        setBookingConfirmed(true);
        fetchBookings();
      })
      .catch((err) => console.error('Booking failed:', err));
  };

  const fetchBookings = () => {
    fetch('/api/bookings')
      .then((res) => res.json())
      .then((data) => setBookings(data))
      .catch((err) => console.error('Failed to fetch bookings:', err));
  };

  const filteredBookings = filterDate
    ? bookings.filter((b) => new Date(b.createdAt).toISOString().split("T")[0] === filterDate)
    : bookings;

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Booking Report", 14, 16);
    doc.autoTable({
      startY: 20,
      head: [["ID", "Distance (mi)", "Weight (lbs)", "Quote ($)", "Created At"]],
      body: filteredBookings.map((b) => [
        b.id,
        b.distance,
        b.weight,
        b.quote?.toFixed(2) || "0.00",
        new Date(b.createdAt).toLocaleString(),
      ]),
    });
    doc.save("booking_report.pdf");
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-4xl font-bold mb-6 text-center">Aggregate Trucking Platform</h1>
      <div className="mt-10 max-w-2xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4 text-center flex items-center justify-center gap-2">
          <List className="w-6 h-6" /> Recent Bookings
        </h2>
        <div className="mb-4 text-center">
          <Label htmlFor="filter-date" className="mr-2">Filter by Date:</Label>
          <Input
            id="filter-date"
            type="date"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            className="max-w-xs inline-block"
          />
          <Button className="ml-4" onClick={exportToPDF}>
            <FileText className="w-4 h-4 mr-2" /> Export PDF
          </Button>
        </div>
        {filteredBookings.length === 0 ? (
          <p className="text-center text-gray-600">No bookings found for this date.</p>
        ) : (
          <ul className="bg-white rounded-xl shadow divide-y">
            {filteredBookings.map((b) => (
              <li key={b.id} className="p-4 text-left">
                <p><strong>ID:</strong> {b.id}</p>
                <p><strong>Distance:</strong> {b.distance} miles</p>
                <p><strong>Weight:</strong> {b.weight} lbs</p>
                <p><strong>Quote:</strong> ${b.quote?.toFixed(2) || "0.00"}</p>
                <p className="text-sm text-gray-500">Created: {new Date(b.createdAt).toLocaleString()}</p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
