import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { distance, weight, quote } = req.body;
    const booking = await prisma.booking.create({ data: { distance, weight, quote } });
    res.status(201).json(booking);
  } else if (req.method === 'GET') {
    const bookings = await prisma.booking.findMany({ orderBy: { createdAt: 'desc' } });
    res.status(200).json(bookings);
  } else {
    res.setHeader('Allow', ['POST', 'GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}
