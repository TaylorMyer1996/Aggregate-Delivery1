import React from "react";
import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";

const center = { lat: 37.7749, lng: -122.4194 };
const containerStyle = { width: "100%", height: "100%" };

export default function Map() {
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "",
  });

  return isLoaded ? (
    <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={10}>
      <Marker position={center} />
    </GoogleMap>
  ) : (
    <div>Loading map...</div>
  );
}
